/* 
  File:   main.cpp
  Author: Josiah Phillips
  Created on January 10, 2017, 11:20 PM
  Purpose:  Distance per Tank of Gas
 */

#include <iostream>
using namespace std;
	 
int main()

{

int distance;

cout << "Town: ";

distance = 20 * 21.5;

cout << " "

<< distance << endl;

cout << "Highway: ";

distance = 20 * 26.8;

cout << " "

<< distance << endl;

	}


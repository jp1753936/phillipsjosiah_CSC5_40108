/* 
  File:   main.cpp
  Author: Josiah Phillips
  Created on January 10, 2017, 9:49 PM
  Purpose:  Sum of Two Numbers
 */

#include <iostream>
 using namespace std;

int main()

{

int numberone = 62;

int numbertwo = 99;

int total = numberone + numbertwo;

//programology

cout << "The sum of " << numberone << " + " << numbertwo << " = " << total << endl;

cout << endl;

return 0;

}

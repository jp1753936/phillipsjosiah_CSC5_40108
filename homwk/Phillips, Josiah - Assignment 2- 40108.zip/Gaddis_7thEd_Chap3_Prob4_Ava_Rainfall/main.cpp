/* 
  File:   main.cpp
  Author: Josiah Phillips
  Created on January 12, 2017, 12:42 PM
  Purpose:  Average Rainfall
 */ 

#include <iostream>
using namespace std;

int main()
{
int years;

// Get the amount of years.
cout << "Enter how many years of rainfall: ";
cin >> years;

double avgRain = 0;
double rainSum = 0;
int count = 0;
double monthlyTotals[12];
string outRainSum;
string lowMonth;
string highMonth="January";
string monthNames[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
cout << "Please enter the amount of rainfall for each month: " << endl;

    return 0;
}